package com.example.counteractivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class CounterActivity extends AppCompatActivity {
    static int count = 0;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_counter);

        Button btnadd = (Button) findViewById(R.id.btn_add);
        Button btnreduce = (Button) findViewById(R.id.btn_reduce);
        Button btnclear = (Button) findViewById(R.id.btn_clear);
        TextView text1 = (TextView) findViewById(R.id.text1);
        btnadd.setOnClickListener(v->{
            count = count+1;
            text1.setText("The current number is : "+count);
        });
        btnreduce.setOnClickListener(v->{
            count = count-1;
            text1.setText("The current number is : "+count);
        });
        btnclear.setOnClickListener(v->{
            count = 0;
            text1.setText("The current number is : "+count);
        });

    }
}